
// registration is done by including XnStatusRegister *before* including the list of errors
#include <XnStatusRegister.h>
#include "XnLinkStatusCodes.h"
